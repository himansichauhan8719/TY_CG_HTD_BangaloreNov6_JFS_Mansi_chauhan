package com.capgemini.foresterymanagementsystemsprngboot.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.foresterymanagementsystemsprngboot.dto.Client;

@Repository
public class ClientDaoImpl implements ClientDao {

	@PersistenceUnit
	EntityManagerFactory factory;

	@Override
	public boolean addClient(Client cbean) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			manager.persist(cbean);
			transaction.commit();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public Client getClient(int clientId) {
		EntityManager manager = factory.createEntityManager();
		Client haulier = manager.find(Client.class, clientId);
		return haulier;
	}

	@Override
	public List<Client> getAllClient() {
		EntityManager manager = factory.createEntityManager();
		String getall = "from Haulier";
		TypedQuery<Client> query = manager.createQuery(getall, Client.class);
		return query.getResultList();
	}

	@Override
	public boolean deleteClient(int clientId) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		Client haulier = manager.find(Client.class, clientId);
		if (haulier != null) {
			transaction.begin();
			manager.remove(haulier);
			transaction.commit();
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean updateClient(Client cbean) {
		EntityManager manager = factory.createEntityManager();
		Client haulier1 = manager.find(Client.class, cbean.getClientId());
		EntityTransaction transaction = manager.getTransaction();
		if (haulier1 != null) {
			transaction.begin();
	//		haulier1.setClientId(cbean.getClientId());
			haulier1.setClientName(cbean.getClientName());
			haulier1.setClientPassword(cbean.getClientPassword());
			haulier1.setClientEmail(cbean.getClientEmail());
	//		haulier1.setPostalCode(haulier.getPostalCode());
	//		haulier1.setTelephone(haulier.getTelephone());
	//		haulier1.setTown(haulier.getTown());
			transaction.commit();
			return true;
		} else {
			return false;
		}
	}

}
