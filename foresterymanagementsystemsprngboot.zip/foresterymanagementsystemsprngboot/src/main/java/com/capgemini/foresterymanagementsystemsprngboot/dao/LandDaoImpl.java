package com.capgemini.foresterymanagementsystemsprngboot.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.foresterymanagementsystemsprngboot.dto.Land;

@Repository
public class LandDaoImpl implements LandDao {

	@PersistenceUnit
	EntityManagerFactory factory;

	@Override
	public boolean addLand(Land lbean) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			manager.persist(lbean);
			transaction.commit();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public Land getLand(int landId) {
		EntityManager manager = factory.createEntityManager();
		Land order = manager.find(Land.class, landId);
		return order;
	}

	@Override
	public List<Land> getAllLand() {
		EntityManager manager = factory.createEntityManager();
		String getall = "from Orders";
		TypedQuery<Land> query = manager.createQuery(getall, Land.class);
		return query.getResultList();
	}

	@Override
	public boolean deleteLand(int landId) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		Land order = manager.find(Land.class, landId);
		if (order != null) {
			transaction.begin();
			manager.remove(order);
			transaction.commit();
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean updateLand(Land lbean) {
		EntityManager manager = factory.createEntityManager();
		Land order1 = manager.find(Land.class, lbean.getLandId());
		EntityTransaction transaction = manager.getTransaction();
		if (order1 != null) {
			transaction.begin();
			order1.setLandId(lbean.getLandId());
			order1.setOwnerName(lbean.getOwnerName());
			order1.setLandLocation(lbean.getLandLocation());
			order1.setLandValue(lbean.getLandValue());
	//		order1.setQuantity(order.getQuantity());
			transaction.commit();
			return true;
		} else {
			return false;
		}
	}

}
