package com.capgemini.foresterymanagementsystemsprngboot.controller;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.foresterymanagementsystemsprngboot.dto.Admin;
import com.capgemini.foresterymanagementsystemsprngboot.dto.AdminResponse;
import com.capgemini.foresterymanagementsystemsprngboot.service.AdminService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*", allowCredentials = "true")
public class AdminController {

	@Autowired
	AdminService service;

	@PostMapping(path = "/admin-register", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public AdminResponse register(@RequestBody Admin account) {
		AdminResponse response = new AdminResponse();
		service.register(account);
		response.setStatusCode(201);
		response.setDescription("Success");
		response.setMessage("Account created");
		return response;
	}

	@PostMapping(path = "/admin-login", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public AdminResponse login(@RequestBody Admin credentials) {
		AdminResponse response = new AdminResponse();
		Admin account = service.login(credentials);
		if (account != null) {
			response.setStatusCode(201);
			response.setDescription("Success");
			response.setMessage(" you are successfully Logged in");
			response.setAccount(Arrays.asList(account));
		} else {
			response.setStatusCode(405);
			response.setDescription("Failure to login");
			response.setMessage("Provide valid credentials");
		}
		return response;
	}

}
