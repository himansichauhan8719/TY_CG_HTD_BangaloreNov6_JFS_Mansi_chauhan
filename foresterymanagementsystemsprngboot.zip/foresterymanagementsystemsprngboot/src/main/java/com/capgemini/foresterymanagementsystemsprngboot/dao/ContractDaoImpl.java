package com.capgemini.foresterymanagementsystemsprngboot.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.foresterymanagementsystemsprngboot.dto.Contract;
@Repository
public class ContractDaoImpl implements ContractDao{
	
	@PersistenceUnit
	EntityManagerFactory factory;

	@Override
	public boolean addContract(Contract contract) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			manager.persist(contract);
			transaction.commit();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	@Override
	public Contract getContract(int contractNo) {
		EntityManager manager = factory.createEntityManager();
		Contract contract = manager.find(Contract.class, contractNo);
		return contract;
	}
	@Override
	public List<Contract> getAllContracts() {
		EntityManager manager = factory.createEntityManager();
		String getall = "from Contract";
		TypedQuery<Contract> query = manager.createQuery(getall, Contract.class);
		return query.getResultList();
	}
	@Override
	public boolean deleteContract(int contractNo) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		Contract contract = manager.find(Contract.class, contractNo);
		if (contract != null) {
			transaction.begin();
			manager.remove(contract);
			transaction.commit();
			return true;
		} else {
			return false;
		}
	}
	@Override
	public boolean updateContract(Contract contract) {
			EntityManager manager = factory.createEntityManager();
			Contract contract1 = manager.find(Contract.class,contract.getContractNo());
			EntityTransaction transaction = manager.getTransaction();
			if(contract1!=null) {
			transaction.begin();
			contract1.setCustomerId(contract.getCustomerId());
			contract1.setProductId(contract.getProductId());
			contract1.setHaulierId(contract.getHaulierId());
			contract1.setDeliveryDate(contract.getDeliveryDate());
			contract1.setDeliveryDay(contract.getDeliveryDay());
			contract1.setQuantity(contract.getQuantity());
			transaction.commit();
				return true;
			}else {
				return false;
			}
	}

}
