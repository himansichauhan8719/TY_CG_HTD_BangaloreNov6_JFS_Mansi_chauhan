package com.capgemini.foresterymanagementsystemsprngboot.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.foresterymanagementsystemsprngboot.dto.Admin;
import com.capgemini.foresterymanagementsystemsprngboot.exceptions.AppException;
@Repository
public class AdminDaoImpl implements AdminDao{
	
	@PersistenceUnit
	EntityManagerFactory factory;

	@Override
	public boolean register(Admin account) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			manager.persist(account);
			transaction.commit();
			return true;
		} catch (Exception e) {
			throw new AppException("Account with same email already exists");
		}
	}

	@Override
	public Admin login(Admin credentials) {
		EntityManager manager = factory.createEntityManager();
		String jpql = "from Admin where email=:email";
		TypedQuery<Admin> query = manager.createQuery(jpql, Admin.class);
		query.setParameter("email", credentials.getEmail());
		try {
			Admin account = query.getSingleResult();
			if (account.getPassword().equals(credentials.getPassword())) {
				return account;
			} else {
				System.out.println("here above valid");
				return null;
			}
		} catch (Exception e) {
			throw new AppException("Account does not exist");
		}
	}

	
}
