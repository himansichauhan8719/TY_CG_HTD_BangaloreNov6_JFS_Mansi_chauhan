package com.capgemini.foresterymanagementsystemsprngboot.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.foresterymanagementsystemsprngboot.dto.Client;
import com.capgemini.foresterymanagementsystemsprngboot.dto.ClientResponse;
import com.capgemini.foresterymanagementsystemsprngboot.service.ClientService;

@CrossOrigin
@RestController
public class ClientController {
	@Autowired
	ClientService service;

	@PostMapping(path = "/add-haulier", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ClientResponse addHaulier(@RequestBody Client haulier) {
		ClientResponse response = new ClientResponse();
		if (service.addClient(haulier)) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("haulier added");
		} else {
			response.setStatusCode(401);
			response.setMessage("Failure");
			response.setDescription("haulier with same id already exists");
		}
		return response;
	}

	@GetMapping(path = "/view-haulier/{haulierId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ClientResponse viewHaulier(@PathVariable("haulierId") int haulierId) {
		ClientResponse response = new ClientResponse();
		Client haulier = service.getClient(haulierId);
		if (haulier != null) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("haulier found");
			response.setClient(Arrays.asList(haulier));
		} else {
			response.setStatusCode(401);
			response.setMessage("Failure");
			response.setDescription("haulierid does not exist");
		}
		return response;
	}

	@GetMapping(path = "/view-allhauliers", produces = MediaType.APPLICATION_JSON_VALUE)
	public ClientResponse viewAllHaulier() {
		ClientResponse response = new ClientResponse();
		List<Client> list = service.getAllClient();
		if (list.size() != 0) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("haulier details found");
			response.setClient(list);
		} else {
			response.setStatusCode(401);
			response.setMessage("Failure");
			response.setDescription("No data");
		}
		return response;

	}

	@DeleteMapping(path = "/delete-haulier/{haulierId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ClientResponse deleteHaulier(@PathVariable("haulierId") int haulierId) {
		ClientResponse response = new ClientResponse();
		if (service.deleteClient(haulierId)) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("haulier deleted");
		} else {
			response.setStatusCode(401);
			response.setMessage("Failure");
			response.setDescription("haulier not found");
		}
		return response;
	}

	@PutMapping(path = "/update-haulier", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ClientResponse updateHaulier(@RequestBody Client bean) {
		ClientResponse response = new ClientResponse();
		if (service.updateClient(bean)) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Haulier updated");
		} else {
			response.setStatusCode(401);
			response.setMessage("Failure");
			response.setDescription("Haulier  is not updated");
		}
		return response;
	}

}
