package com.capgemini.foresterymanagementsystemsprngboot.service;

import java.util.List;

import com.capgemini.foresterymanagementsystemsprngboot.dto.Product;

public interface ProductService {

	public boolean addProduct(Product product);

	public Product getProduct(int productId);

	public List<Product> getAllProducts();

	public boolean deleteProduct(int productId);

	public boolean updateProduct(Product product);
}
