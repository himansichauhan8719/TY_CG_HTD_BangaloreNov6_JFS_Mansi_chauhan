package com.capgemini.foresterymanagementsystemsprngboot.dao;

import java.util.List;

import com.capgemini.foresterymanagementsystemsprngboot.dto.Customer;

public interface CustomerDao {

	public boolean addCustomer(Customer customer);

	public Customer getCustomer(int customerId);

	public List<Customer> getAllCustomers();

	public boolean deleteCustomer(int customerId);

	public boolean updateCustomer(Customer customer);

}
