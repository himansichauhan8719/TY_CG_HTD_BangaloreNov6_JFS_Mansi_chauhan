package com.capgemini.foresterymanagementsystemsprngboot.dto;

import java.util.List;

import lombok.Data;

@Data
public class LandResponse {
	private int statusCode;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public LandResponse() {
		super();
	}
	public LandResponse(int statusCode, String message, String description, List<Land> order) {
		super();
		this.statusCode = statusCode;
		this.message = message;
		this.description = description;
		this.order = order;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<Land> getOrder() {
		return order;
	}
	public void setOrder(List<Land> order) {
		this.order = order;
	}
	private String message;
	private String description;
	private List<Land> order;

}
