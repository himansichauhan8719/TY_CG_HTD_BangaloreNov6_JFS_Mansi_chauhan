package com.capgemini.foresterymanagementsystemsprngboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.foresterymanagementsystemsprngboot.dao.AdminDao;
import com.capgemini.foresterymanagementsystemsprngboot.dto.Admin;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminDao dao;

	@Override
	public boolean register(Admin account) {

		return dao.register(account);
	}

	@Override
	public Admin login(Admin credentials) {

		return dao.login(credentials);
	}

}
