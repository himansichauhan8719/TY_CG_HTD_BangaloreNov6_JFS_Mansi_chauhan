package com.capgemini.foresterymanagementsystemsprngboot.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.foresterymanagementsystemsprngboot.dto.Land;
import com.capgemini.foresterymanagementsystemsprngboot.dto.LandResponse;
import com.capgemini.foresterymanagementsystemsprngboot.service.LandService;

@CrossOrigin
@RestController
public class LandController {
	@Autowired
	LandService service;

	@PostMapping(path = "/add-order", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public LandResponse addHaulier(@RequestBody Land order) {
		LandResponse response = new LandResponse();
		if (service.addLand(order)) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("order added");
		} else {
			response.setStatusCode(401);
			response.setMessage("Failure");
			response.setDescription("order with same no already exists");
		}
		return response;
	}

	@GetMapping(path = "/view-order/{orderNo}", produces = MediaType.APPLICATION_JSON_VALUE)
	public LandResponse viewOrder(@PathVariable("orderNo") int orderNo) {
		LandResponse response = new LandResponse();
		Land order = service.getLand(orderNo);
		if (order != null) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("order found");
			response.setOrder(Arrays.asList(order));
		} else {
			response.setStatusCode(401);
			response.setMessage("Failure");
			response.setDescription("orderNo does not exist");
		}
		return response;
	}

	@GetMapping(path = "/view-allorders", produces = MediaType.APPLICATION_JSON_VALUE)
	public LandResponse viewAllOrder() {
		LandResponse response = new LandResponse();
		List<Land> list = service.getAllLand();
		if (list.size() != 0) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("order details found");
			response.setOrder(list);
		} else {
			response.setStatusCode(401);
			response.setMessage("Failure");
			response.setDescription("No data");
		}
		return response;

	}

	@DeleteMapping(path = "/delete-order/{orderNo}", produces = MediaType.APPLICATION_JSON_VALUE)
	public LandResponse deleteOrder(@PathVariable("orderNo") int orderNo) {
		LandResponse response = new LandResponse();
		if (service.deleteLand(orderNo)) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("order deleted");
		} else {
			response.setStatusCode(401);
			response.setMessage("Failure");
			response.setDescription("order not found");
		}
		return response;
	}

	@PutMapping(path = "/update-order", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public LandResponse updateOrder(@RequestBody Land bean) {
		LandResponse response = new LandResponse();
		if (service.updateLand(bean)) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("order updated");
		} else {
			response.setStatusCode(401);
			response.setMessage("Failure");
			response.setDescription("order is not updated");
		}
		return response;
	}

}
