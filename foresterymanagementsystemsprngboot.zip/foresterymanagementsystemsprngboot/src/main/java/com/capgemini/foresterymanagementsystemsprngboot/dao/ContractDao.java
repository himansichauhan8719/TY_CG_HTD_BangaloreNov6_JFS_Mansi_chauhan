package com.capgemini.foresterymanagementsystemsprngboot.dao;

import java.util.List;

import com.capgemini.foresterymanagementsystemsprngboot.dto.Contract;

public interface ContractDao {
	
//	public Contract login(Contract credentials);

	public boolean addContract(Contract contract);

	public Contract getContract(int contractNo);

	public List<Contract> getAllContracts();

	public boolean deleteContract(int contractNo);

	public boolean updateContract(Contract contract);

}
