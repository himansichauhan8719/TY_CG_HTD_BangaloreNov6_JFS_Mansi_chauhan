package com.capgemini.foresterymanagementsystemsprngboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.foresterymanagementsystemsprngboot.dao.LandDao;
import com.capgemini.foresterymanagementsystemsprngboot.dto.Land;

@Service
public class LandServiceImpl implements LandService {

	@Autowired
	private LandDao dao;

	@Override
	public boolean addLand(Land lbean) {

		return dao.addLand(lbean);
	}

	@Override
	public Land getLand(int landId) {

		return dao.getLand(landId);
	}

	@Override
	public List<Land> getAllLand() {

		return dao.getAllLand();
	}

	@Override
	public boolean deleteLand(int landId) {

		return dao.deleteLand(landId);
	}

	@Override
	public boolean updateLand(Land lbean) {

		return dao.updateLand(lbean);
	}

}
