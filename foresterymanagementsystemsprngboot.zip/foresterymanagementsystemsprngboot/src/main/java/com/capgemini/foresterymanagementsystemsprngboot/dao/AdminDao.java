package com.capgemini.foresterymanagementsystemsprngboot.dao;

import com.capgemini.foresterymanagementsystemsprngboot.dto.Admin;

public interface AdminDao {
	public boolean register(Admin account);

	public Admin login(Admin credentials);

}
