package com.capgemini.foresterymanagementsystemsprngboot.dao;

import java.util.List;

import com.capgemini.foresterymanagementsystemsprngboot.dto.Client;

public interface ClientDao {

	public boolean addClient(Client cbean);

	public Client getClient(int clientId);

	public List<Client> getAllClient();

	public boolean deleteClient(int clientId);

	public boolean updateClient(Client cbean);

}
