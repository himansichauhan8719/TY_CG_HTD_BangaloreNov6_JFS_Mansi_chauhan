package com.capgemini.foresterymanagementsystemsprngboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForesterymanagementsystemsprngbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ForesterymanagementsystemsprngbootApplication.class, args);
	}

}
