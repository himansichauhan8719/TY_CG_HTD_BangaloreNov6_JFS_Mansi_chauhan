package com.capgemini.foresterymanagementsystemsprngboot.dao;

import java.util.List;

import com.capgemini.foresterymanagementsystemsprngboot.dto.Land;

public interface LandDao {

	public boolean addLand(Land lbean);

	public Land getLand(int landId);

	public List<Land> getAllLand();

	public boolean deleteLand(int landId);

	public boolean updateLand(Land lbean);
}
