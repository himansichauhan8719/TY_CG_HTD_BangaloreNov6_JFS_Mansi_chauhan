package com.capgemini.foresterymanagementsystemsprngboot.exceptions;

@SuppressWarnings("serial")
public class AppException extends RuntimeException {

	String msg;

	public AppException(String msg) {
		this.msg = msg;
	}

	@Override
	public String getMessage() {
		return msg;
	}

}
