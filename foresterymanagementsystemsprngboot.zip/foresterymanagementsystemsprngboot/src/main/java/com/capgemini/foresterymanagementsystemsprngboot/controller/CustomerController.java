package com.capgemini.foresterymanagementsystemsprngboot.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.foresterymanagementsystemsprngboot.dto.Customer;
import com.capgemini.foresterymanagementsystemsprngboot.dto.CustomerResponse;
import com.capgemini.foresterymanagementsystemsprngboot.service.CustomerService;

@CrossOrigin
@RestController
public class CustomerController {

	@Autowired
	CustomerService service;

	@PostMapping(path = "/add-customer", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public CustomerResponse addCustomer(@RequestBody Customer customer) {
		CustomerResponse response = new CustomerResponse();
		if (service.addCustomer(customer)) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("customer added");
		} else {
			response.setStatusCode(401);
			response.setMessage("Failure");
			response.setDescription("customer with same id already exists");
		}
		return response;
	}

	@GetMapping(path = "/view-customer/{customerId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public CustomerResponse viewCustomer(@PathVariable("customerId") int customerId) {
		CustomerResponse response = new CustomerResponse();
		Customer customer = service.getCustomer(customerId);
		if (customer != null) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("customer found");
			response.setCustomer(Arrays.asList(customer));
		} else {
			response.setStatusCode(401);
			response.setMessage("Failure");
			response.setDescription("customerid does not exist");
		}
		return response;
	}

	@GetMapping(path = "/view-allcustomers", produces = MediaType.APPLICATION_JSON_VALUE)
	public CustomerResponse viewAllCustomer() {
		CustomerResponse response = new CustomerResponse();
		List<Customer> list = service.getAllCustomers();
		if (list.size() != 0) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("customer details found");
			response.setCustomer(list);
		} else {
			response.setStatusCode(401);
			response.setMessage("Failure");
			response.setDescription("No data");
		}
		return response;

	}

	@DeleteMapping(path = "/delete-customer/{customerId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public CustomerResponse deleteCustomer(@PathVariable("customerId") int customerId) {
		CustomerResponse response = new CustomerResponse();
		if (service.deleteCustomer(customerId)) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("customer deleted");
		} else {
			response.setStatusCode(401);
			response.setMessage("Failure");
			response.setDescription("customer not found");
		}
		return response;
	}

	@PutMapping(path = "/update-customer", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public CustomerResponse updateCustomer(@RequestBody Customer bean) {
		CustomerResponse response = new CustomerResponse();
		if (service.updateCustomer(bean)) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Customer updated");
		} else {
			response.setStatusCode(401);
			response.setMessage("Failure");
			response.setDescription("Customer  is not updated");
		}
		return response;
	}

}
