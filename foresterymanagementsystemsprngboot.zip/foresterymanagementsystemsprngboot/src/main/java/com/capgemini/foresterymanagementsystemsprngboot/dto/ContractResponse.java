package com.capgemini.foresterymanagementsystemsprngboot.dto;

import java.util.List;

import lombok.Data;

@Data
public class ContractResponse {
	private int statusCode;
	private String message;
	private String description;
	private List<Contract> contract;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<Contract> getContract() {
		return contract;
	}
	public void setContract(List<Contract> contract) {
		this.contract = contract;
	}
	public ContractResponse() {
		super();
	}
	public ContractResponse(int statusCode, String message, String description, List<Contract> contract) {
		super();
		this.statusCode = statusCode;
		this.message = message;
		this.description = description;
		this.contract = contract;
	}


}
