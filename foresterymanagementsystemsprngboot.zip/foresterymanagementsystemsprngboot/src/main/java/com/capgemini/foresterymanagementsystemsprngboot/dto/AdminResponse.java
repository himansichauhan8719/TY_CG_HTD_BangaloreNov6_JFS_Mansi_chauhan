package com.capgemini.foresterymanagementsystemsprngboot.dto;

import java.util.List;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
public class AdminResponse {

	private int statusCode;
	private String message;
	private String description;
//	private List<Admin> admin;
	private List<Admin> account;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public AdminResponse(int statusCode, String message, String description, List<Admin> account) {
		super();
		this.statusCode = statusCode;
		this.message = message;
		this.description = description;
		this.account = account;
	}
	public AdminResponse() {
		super();
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<Admin> getAccount() {
		return account;
	}
	public void setAccount(List<Admin> account) {
		this.account = account;
	}

}
