package com.capgemini.foresterymanagementsystemsprngboot.service;

import com.capgemini.foresterymanagementsystemsprngboot.dto.Admin;

public interface AdminService {
	
	public boolean register(Admin account);

	public Admin login(Admin credentials);

}
