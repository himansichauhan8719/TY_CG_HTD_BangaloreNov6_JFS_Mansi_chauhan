package com.capgemini.foresterymanagementsystemsprngboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.foresterymanagementsystemsprngboot.dao.ClientDao;
import com.capgemini.foresterymanagementsystemsprngboot.dto.Client;

@Service
public class ClientServiceImpl implements ClientService {

	@Autowired
	private ClientDao dao;

	@Override
	public boolean addClient(Client cbean) {

		return dao.addClient(cbean);
	}

	@Override
	public Client getClient(int clientId) {

		return dao.getClient(clientId);
	}

	@Override
	public List<Client> getAllClient() {

		return dao.getAllClient();
	}

	@Override
	public boolean deleteClient(int clientId) {

		return dao.deleteClient(clientId);
	}

	@Override
	public boolean updateClient(Client cbean) {

		return dao.updateClient(cbean);
	}

}
