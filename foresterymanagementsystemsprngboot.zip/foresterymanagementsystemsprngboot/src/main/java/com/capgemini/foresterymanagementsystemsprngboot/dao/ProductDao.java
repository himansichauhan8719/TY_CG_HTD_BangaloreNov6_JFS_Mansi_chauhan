package com.capgemini.foresterymanagementsystemsprngboot.dao;

import java.util.List;

import com.capgemini.foresterymanagementsystemsprngboot.dto.Product;

public interface ProductDao {

	public boolean addProduct(Product product);

	public Product getProduct(int productId);

	public List<Product> getAllProducts();

	public boolean deleteProduct(int productId);

	public boolean updateProduct(Product product);
}
