package com.capgemini.foresterymanagementsystemsprngboot.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="Land")
public class Land {
	public int getLandId() {
		return landId;
	}
	public void setLandId(int landId) {
		this.landId = landId;
	}
	public String getOwnerName() {
		return OwnerName;
	}
	public Land(int landId, String ownerName, String landLocation, double landValue) {
		super();
		this.landId = landId;
		OwnerName = ownerName;
		this.landLocation = landLocation;
		this.landValue = landValue;
	}
	public Land() {
		super();
	}
	public void setOwnerName(String ownerName) {
		OwnerName = ownerName;
	}
	public String getLandLocation() {
		return landLocation;
	}
	public void setLandLocation(String landLocation) {
		this.landLocation = landLocation;
	}
	public double getLandValue() {
		return landValue;
	}
	public void setLandValue(double landValue) {
		this.landValue = landValue;
	}
	@Id
	@GeneratedValue
	@Column(unique=true)
	private int landId;
	@Column
	private String OwnerName;
	@Column
	private String landLocation;
	@Column
	private double landValue;


}
