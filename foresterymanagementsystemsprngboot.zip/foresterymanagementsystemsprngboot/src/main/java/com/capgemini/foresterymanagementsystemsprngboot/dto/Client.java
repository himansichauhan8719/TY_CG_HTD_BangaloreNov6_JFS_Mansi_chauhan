package com.capgemini.foresterymanagementsystemsprngboot.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="client")
public class Client {
	public int getClientId() {
		return clientId;
	}

	public void setClientId(int clientId) {
		this.clientId = clientId;
	}

	public Client() {
		super();
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public Client(int clientId, String clientName, String clientPassword, String clientEmail) {
		super();
		this.clientId = clientId;
		this.clientName = clientName;
		this.clientPassword = clientPassword;
		this.clientEmail = clientEmail;
	}

	public String getClientPassword() {
		return clientPassword;
	}

	public void setClientPassword(String clientPassword) {
		this.clientPassword = clientPassword;
	}

	public String getClientEmail() {
		return clientEmail;
	}

	public void setClientEmail(String clientEmail) {
		this.clientEmail = clientEmail;
	}

	@Id
	@GeneratedValue
	@Column(name = "id")
	private int clientId;
	
	@Column(name = "name")
	private String clientName;
	
	@Column(name = "password")
	private String clientPassword;
	
	@Column(name = "email")
	private String clientEmail;



}
