package com.capgemini.foresterymanagementsystemsprngboot.dto;

import java.util.List;

import lombok.Data;
@Data
public class CustomerResponse {
	private int statusCode;
	private String message;
	private String description;
	private List<Customer> customer;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<Customer> getCustomer() {
		return customer;
	}
	public void setCustomer(List<Customer> customer) {
		this.customer = customer;
	}
	public CustomerResponse(int statusCode, String message, String description, List<Customer> customer) {
		super();
		this.statusCode = statusCode;
		this.message = message;
		this.description = description;
		this.customer = customer;
	}
	public CustomerResponse() {
		super();
	}


}
