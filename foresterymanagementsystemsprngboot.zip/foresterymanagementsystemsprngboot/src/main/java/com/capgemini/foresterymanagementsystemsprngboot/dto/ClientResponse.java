package com.capgemini.foresterymanagementsystemsprngboot.dto;

import java.util.List;

import lombok.Data;
@Data
public class ClientResponse {
	private int statusCode;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode; 
	}
	public ClientResponse() {
		super();
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public ClientResponse(int statusCode, String message, String description, List<Client> client) {
		super();
		this.statusCode = statusCode;
		this.message = message;
		this.description = description;
		this.client = client;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<Client> getClient() {
		return client;
	}
	public void setClient(List<Client> client) {
		this.client = client;
	}
	private String message;
	private String description;
	private List<Client> client;


}
