package com.capgemini.foresterymanagementsystemsprngboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.foresterymanagementsystemsprngboot.dao.ContractDao;
import com.capgemini.foresterymanagementsystemsprngboot.dto.Contract;

@Service
public class ContractServiceImpl implements ContractService {
	@Autowired
	private ContractDao dao;

	@Override
	public boolean addContract(Contract contract) {
		return dao.addContract(contract);
	}

	@Override
	public Contract getContract(int contractNo) {
		return dao.getContract(contractNo);
	}

	@Override
	public List<Contract> getAllContracts() {
		return dao.getAllContracts();
	}

	@Override
	public boolean deleteContract(int contractNo) {
		return dao.deleteContract(contractNo);
	}

	@Override
	public boolean updateContract(Contract contract) {
		return dao.updateContract(contract);
	}
}
